# -*- encoding: utf-8 -*-
"""
@File    : data_ob.py
@Time    : 2019/10/8 12:09
@Author  : pandaboy
@Email   : pandaboy11223@gmail.com
@Software: PyCharm
"""
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import matplotlib

path = r'E:\厦门银行数据\train_target.csv'
def show_target(path):
    '''
    输入文件路径,找到违约人数，输出占比图
    :param path:
    :return:
    '''
    with open(path,'r',encoding='utf-8')  as f:
        data = pd.read_csv(f)

        matplotlib.rcParams['font.sans-serif'] = ['SimHei']  # 用黑体显示中文
        matplotlib.rcParams['axes.unicode_minus'] = False  # 正常显示负号
        # print(len(data[data['target']==0]),len(data[data['target']==1]))
        labels = [u'正常人数占比', u'违约人数占比']  # 定义标签
        sizes = [len(data[data['target']==0]), len(data[data['target']==1])]  # 每块值
        colors = ['lightskyblue', 'yellowgreen']  # 每块颜色定义
        explode = (0, 0)  # 将某一块分割出来，值越大分割出的间隙越大
        patches, text1, text2 = plt.pie(sizes,
                                        explode=explode,
                                        labels=labels,
                                        colors=colors,
                                        autopct='%3.2f%%',  # 数值保留固定小数位
                                        shadow=False,  # 无阴影设置
                                        startangle=90,  # 逆时针起始角度设置
                                        pctdistance=0.6)  # 数值距圆心半径倍数距离
        # patches饼图的返回值，texts1饼图外label的文本，texts2饼图内部的文本
        # x，y轴刻度设置一致，保证饼图为圆形
        plt.axis('equal')
        plt.show()
        return data[data['target']==1]['id']
id_list = show_target(path)
# print(id_list)
train_path = r'E:\厦门银行数据\train.csv'
with open(train_path,'r',encoding='utf-8') as f:
    data = pd.read_csv(f)
    # print(data.describe())
    print(data.columns.values.tolist())
    # print(data['certValidBegin'].head())
    # for name in data.columns.values:
    #     print('列名称为%s'%name)
    #     print(data[name].describe())
    #     print('-------------------')