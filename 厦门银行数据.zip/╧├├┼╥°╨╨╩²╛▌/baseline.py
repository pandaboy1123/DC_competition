# -*- encoding: utf-8 -*-
"""
@File    : baseline.py
@Time    : 2019/10/8 16:06
@Author  : pandaboy
@Email   : pandaboy11223@gmail.com
@Software: PyCharm
"""
import pandas as pd
import numpy as np
import lightgbm as lgb
from sklearn.metrics import roc_auc_score,accuracy_score

target_path = r'E:\厦门银行数据\train_target.csv'
train_path = r'E:\厦门银行数据\train.csv'
test_path = r'E:\厦门银行数据\test.csv'
col_name_l = ['certId', 'loanProduct', 'gender', 'age', 'dist', 'edu', 'job', 'lmt', 'basicLevel','unpayIndvLoan', 'unpayOtherLoan', 'unpayNormalLoan', '5yearBadloan']
with open(target_path,'r',encoding='utf-8') as f:
    target_data = pd.read_csv(f)
with open(train_path,'r',encoding='utf-8') as f:
    train_data = pd.read_csv(f)
with open(test_path,'r',encoding='utf-8') as f:
    test_data = pd.read_csv(f)
data = pd.merge(train_data,target_data,how='left',on='id')
# print(data.columns.values,len(data))
col_name = data.columns.values.tolist()
col_name.remove('id')
dtrain = lgb.Dataset(
        data[col_name_l].values, label=data['target'].values)
newcol = col_name.copy()
newcol.remove('target')
dtest = test_data[col_name_l].values

params = {'num_leaves': 10,
         'min_data_in_leaf': 42,
         'objective': 'binary',
         'max_depth': 18,
         'learning_rate': 0.01,
         'boosting': 'gbdt',
         'bagging_freq': 6,
         # 'bagging_fraction': 0.8,
         'feature_fraction': 0.9,
         'bagging_seed': 11,
         'reg_alpha': 2,
         'reg_lambda': 5,
         'random_state': 42,
         'metric': 'auc',
         'verbosity': -1,
         # 'subsample': 0.9,
         'min_gain_to_split': 0.01077313523861969,
         'min_child_weight': 19.428902804238373,
         'num_threads': 4}

lgb.cv(params=params, train_set=dtrain, stratified=False, num_boost_round=800, early_stopping_rounds=200, nfold=10,
           verbose_eval=True, metrics='auc')
bst = lgb.train(params, dtrain)
x_pre = bst.predict(data[col_name].values, num_iteration=bst.best_iteration)

y_pre = bst.predict(dtest, num_iteration=bst.best_iteration)
# print(y_pre)
# x_pre = [i*28 for i in x_pre]
# y_pre = [i*28 for i in y_pre]
# print(len([i for i in x_pre if i>0.5]))
# print(len([i for i in x_pre if i>0.5])/len(x_pre))
x_test = data['target']
# x_pre = [(1 if i>0.5 else 0)for i in x_pre]
# y_pre = [(1 if i>0.5 else 0)for i in y_pre]
# print(int(len(test_data)*0.63/100))
# print(int(len(train_data)*0.63/100))
new_data = pd.DataFrame()
new_data['id'] = test_data['id']
new_data['target'] = y_pre
new_data.sort_values('target',ascending=False,inplace=True)
new_data.iloc[:int(len(test_data)*0.63/100),1] =1
new_data.iloc[int(len(test_data)*0.63/100):,1] =0
# print(new_data.head())
new_data.to_csv('sample.csv',index=False)
# print(roc_auc_score(x_test,x_pre))